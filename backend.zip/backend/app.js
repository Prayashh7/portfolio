import path from "node:path";
import { fileURLToPath } from "node:url";
import cookieParser from "cookie-parser";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import { env } from "./config/env.js";
import { errorHandler, notFoundHandler } from "./middleware/errors.js";
import { apiLimiter } from "./middleware/rateLimit.js";
import adminRoutes from "./routes/admin.js";
import authRoutes from "./routes/auth.js";
import publicRoutes from "./routes/public.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MEDIA_DIR = path.join(HERE, "public", "media");

const app = express();

/* Behind a reverse proxy the client IP arrives in a header, and rate limiting is
   worthless without it. Left off in development, where there is no proxy to trust. */
if (env.isProduction) app.set("trust proxy", 1);

app.use(
  helmet({
    /* The API and the site are on different origins in every deployment, so
       images have to be readable cross-origin. */
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);

app.use(
  cors({
    origin(origin, done) {
      // No Origin header means a same-origin or non-browser request.
      if (!origin || env.corsOrigins.includes(origin)) return done(null, true);
      done(new Error("ORIGIN_NOT_ALLOWED"));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "X-CSRF-Token"],
    maxAge: 86_400,
  })
);

app.use(cookieParser());
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));

/* Served before the rate limiter: a page full of images should not eat into the
   API budget. A missing file falls through to the JSON 404 below. */
app.use(
  "/media",
  express.static(MEDIA_DIR, {
    maxAge: env.isProduction ? "7d" : 0,
    index: false,
    dotfiles: "ignore",
  })
);

app.use("/api", apiLimiter);
app.use("/api", publicRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

export default app;
